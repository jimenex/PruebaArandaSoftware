import './App.css';
import React, { Component, useState} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Table, Button, Container, Modal, ModalBody, ModalHeader, ModalFooter, FormGroup} from 'reactstrap';
import axios from "axios";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEdit, faTrashAlt, faSearch } from '@fortawesome/free-solid-svg-icons';

//URL Base BackEnd
const baseUrl = "https://localhost:44393/api/";



 
export default class app extends Component
{   
  
    constructor()
    {
        super();
        this.state={
          data:[],
          modalActualizar: false,
          modalInsertar: false,
          modalEliminar: false,
          imagenBase64:"",
          form: {
            ProductoId: 0,
            Nombre: "",
            Descripcion: "",
            Categoria:"",
            Imagen:"",
          },      
        };        
    }   

    //Inicializas la App
    inicializarApp=()=>{
      axios.get(baseUrl+"GetListaProductos").then(response=>{this.setState({data: response.data});}).catch(error=>{
        console.log(error.message)
      }); 
    }

    //Inicio
    componentDidMount(){
      this.inicializarApp();
    }  

    //Despliega Modal de Actualizar
    mostrarModalActualizar = (dato) => {
      this.setState({
        form: dato,
        modalActualizar: true,
      });
    };
  
    //Cierra Modal de Actualizar
    cerrarModalActualizar = () => {
      this.setState({ modalActualizar: false });
    };
  
    //Despliega Modal de Insertar
    mostrarModalInsertar = () => {
      this.setState({
        modalInsertar: true,
      });
    };

    //Cierra Modal de insertar
    cerrarModalInsertar = () => {
      this.setState({ modalInsertar: false });
    };
    
    //Seleccionar Desarrollador
    seleccionarDesarrollador=(dato)=>{
      this.setState({
        form: dato
      });
    }

    //Proceso de Editar  
    editar = (dato) => {
      var contador = 0;
      var arreglo = this.state.data;
      arreglo.map((registro) => {
        if (dato.ProductoId == registro.ProductoId) {
          arreglo[contador].Nombre = dato.Nombre;
          arreglo[contador].Descripcion = dato.Descripcion;
          arreglo[contador].Categoria = dato.Categoria;
          arreglo[contador].Imagen = dato.Imagen;
        }
        contador++;
      });
      axios.put(baseUrl+"EditarProducto/"+this.state.form.ProductoId,this.state.form).then(response=>{
        this.setState({ data: arreglo, modalActualizar: false });
      }).catch(error=>{
        console.log(error.message)
      });      
    };
  
     //proceso de Eliminar 
    eliminar = () => {
        var contador = 0;
        var arreglo = this.state.data;
        arreglo.map((registro) => {
          if (this.state.form.ProductoId == registro.ProductoId) {
            arreglo.splice(contador, 1);
          }
          contador++;
        });        
        axios.delete(baseUrl+"EliminarProducto/"+this.state.form.ProductoId).then(response=>{
          this.setState({ data: arreglo, modalActualizar: false });
        }).catch(error=>{
          console.log(error.message)
        });  
      //}
    };
  
    //Proceso de Insertar  
    insertar=async()=>{  
      await axios.post(baseUrl+"CrearProducto", this.state.form).then(response=>{
        this.cerrarModalInsertar();
        this.inicializarApp();
        }).catch(error=>{
          console.log(error.message)
        });        
    }

    //Proceso de Buscar
    buscar=(value)=>{  
      axios.get(baseUrl+"GetProducto/"+value).then(response=>{this.setState({data: response.data});}).catch(error=>{
        window.alert(error.message)
      });
    }

    //Actualiza Objeto en cada cambio
    handleChange = (e) => {      
      this.setState({
        form: {
          ...this.state.form,
          [e.target.name]: e.target.value,           
        },
      });
    };

     //Buscar
     handleSearch = (e) => {
      if (e.target.value === null || e.target.value ==""){
        this.inicializarApp();
      }
      else{
        this.buscar(e.target.value)  
      }   
    };    

    //Previsualizar Imagen
    convertirBase64=(e)=>{     
        var reader=new FileReader();
        reader.readAsDataURL(e);
        reader.onload=()=>{              
          console.log("Base64:"+reader.result);
        } 
    }    

    //Renderiza la Pagina
    render(){
      return(
            <>
              {/* Pagina Principal*/}
              <Container>              
                <br />  
                <table>
                  <tbody>
                    <tr>
                      <td>
                        <Button className="btnCrear" color="success" onClick={()=>this.mostrarModalInsertar()}>Crear Producto</Button>                
                      </td>
                      <td className="containerInput">                       
                        <input
                          className="form-control inputBuscar"
                          placeholder="Búsqueda"
                          name="id"
                          type="text"
                          onChange={this.handleSearch}
                        />
                        <button className="btn btn-success">
                          <FontAwesomeIcon icon={faSearch} onClick={() => this.buscar()}/>
                        </button>
                      </td>
                    </tr>
                  </tbody>
                </table>
                <Table>
                  <thead>
                    <tr>
                      <th>Id</th>
                      <th>Nombre</th>
                      <th>Descripción</th>
                      <th>Categoria</th>  
                      <th>Imagen</th> 
                      <th>Operaciones</th>                     
                    </tr>
                  </thead>
                  <tbody>
                    {this.state.data.map((dato) => (
                      <tr key={dato.ProductoId}>
                        <td>{dato.ProductoId}</td>
                        <td>{dato.Nombre}</td>
                        <td>{dato.Descripcion}</td>
                        <td>{dato.Categoria}</td>
                        <td><img  width="100" height="100" src={dato.Imagen}/></td>  
                        <td>
                          <Button
                            color="primary"
                            onClick={() => this.mostrarModalActualizar(dato)}
                          >
                          <FontAwesomeIcon icon={faEdit}/>
                          </Button>{" "}
                          <Button color="danger" onClick={()=>{this.seleccionarDesarrollador(dato); this.setState({modalEliminar: true})}}><FontAwesomeIcon icon={faTrashAlt}/></Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              </Container> 
              
              {/* Modal de Actualizar */}
              <Modal isOpen={this.state.modalActualizar}  autoFocus={false}>
                <ModalHeader>
                  <div><h3>Editar Producto</h3></div>
                </ModalHeader>
                <ModalBody>
                  <FormGroup>
                    <label  style={{ fontWeight: 'bold' }}>Id: {this.state.form.ProductoId}</label>            
                  </FormGroup>              
                  <FormGroup>
                    <label>Nombre:</label>
                    <input
                      autoFocus={true}
                      className="form-control"
                      name="Nombre"
                      type="text"
                      onChange={this.handleChange}
                      value={this.state.form.Nombre}
                    />
                  </FormGroup>              
                  <FormGroup>
                    <label>Descripcion:</label>
                    <input
                      className="form-control"
                      name="Descripcion"
                      type="text"
                      onChange={this.handleChange}
                      value={this.state.form.Descripcion}
                    />
                  </FormGroup>
                  <FormGroup>
                    <label>Categoria:</label>
                    <select 
                      className="form-control"
                      name="Categoria"
                      type="text"
                      onChange={this.handleChange}
                      value={this.state.form.Categoria}>
                      <option></option>
                      <option>Consolas</option>
                      <option>Video Juegos</option>
                      <option>General</option>
                    </select>                    
                  </FormGroup>                 
                  <FormGroup>
                    <label>Imagen:</label>
                    <input 
                      className="form-control"
                      name="Imagen"
                      type="file"
                      onChange={(e)=>{this.convertirBase64(e.target.files[0])}}                     
                    />
                    <img  width="100" height="100" src={this.state.form.Imagen}/>
                  </FormGroup>
                </ModalBody>
                <ModalFooter>
                  <Button
                    color="primary"
                    onClick={() => this.editar(this.state.form)}
                  >
                    Guardar
                  </Button>
                  <Button
                    color="danger"
                    onClick={() => this.cerrarModalActualizar()}
                  >
                    Cancelar
                  </Button>
                </ModalFooter>
              </Modal>
              
               {/* Modal de Insertar */}
              <Modal isOpen={this.state.modalInsertar} autoFocus={false}>
                <ModalHeader>
                <div><h3>Crear Producto</h3></div>
                </ModalHeader>
                <ModalBody>
                <FormGroup>
                    <label>Nombre:</label>
                    <input
                      autoFocus={true}
                      className="form-control"
                      name="Nombre"
                      type="text"
                      onChange={this.handleChange}                      
                    />
                  </FormGroup>              
                  <FormGroup>
                    <label>Descripcion:</label>
                    <input
                      className="form-control"
                      name="Descripcion"
                      type="text"
                      onChange={this.handleChange}                     
                    />
                  </FormGroup>
                  <FormGroup>
                    <label>Categoria:</label>
                    <select 
                      className="form-control"
                      name="Categoria"
                      type="text"
                      onChange={this.handleChange}>
                      <option></option>
                      <option>Consolas</option>
                      <option>Video Juegos</option>
                      <option>General</option>
                    </select>                    
                  </FormGroup>                 
                  <FormGroup>
                    <label>Imagen:</label>
                    <input 
                      className="form-control"
                      name="Imagen"
                      type="file"
                      onChange={this.handleChange}                     
                    />
                  </FormGroup>
                </ModalBody>
                <ModalFooter>
                  <Button
                    color="primary"
                    onClick={() => this.insertar()}
                  >
                    Insertar
                  </Button>
                  <Button
                    className="btn btn-danger"
                    onClick={() => this.cerrarModalInsertar()}
                  >
                    Cancelar
                  </Button>
                </ModalFooter>
              </Modal>

              {/* Modal de Insertar */}
              <Modal isOpen={this.state.modalEliminar}>
                <ModalBody>
                  Estás seguro que deseas eliminar el producto?<br/><b>{this.state.form.ProductoId} - {this.state.form.Nombre}</b>
                </ModalBody>
                <ModalFooter>
                  <button className="btn btn-danger" onClick={()=>{this.eliminar(); this.setState({modalEliminar: false})}}>Sí</button>
                  <button className="btn btn-secundary" onClick={()=>this.setState({modalEliminar: false})}>No</button>
                </ModalFooter>
              </Modal>
            </>     
      )
    }
}