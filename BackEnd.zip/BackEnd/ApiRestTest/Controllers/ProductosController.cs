﻿using ApiRestTest.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Web.Http.Cors;

namespace ApiRestTest.Controllers
{
    [EnableCors(origins: "http://localhost:3000", headers: "*", methods: "*")]

    public class ProductosController : ApiController
    {
        [Route("api/GetListaProductos")]
        [HttpGet]
        public List<ProductoModel> GetListaProductos()
        {
            List<ProductoModel> listaProductos;
            try
            {
                using (BDEntities bdModel = new BDEntities())
                {
                    listaProductos = (from data in bdModel.PRODUCTO
                                      select new ProductoModel
                                      {
                                          ProductoId = data.ProductoId,
                                          Nombre = data.Nombre,
                                          Descripcion = data.Descripcion,
                                          Categoria = data.Categoria,
                                          Imagen = data.Imagen
                                      }).ToList();
                }
                return listaProductos;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.GetType().FullName);
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        [Route("api/GetProducto/{valor}")]
        [HttpGet]
        public List<ProductoModel> GetProductos(string valor)
        {
            List<ProductoModel> listaProductos;
            try
            {
                using (BDEntities bdModel = new BDEntities())
                {
                    listaProductos = (from data in bdModel.PRODUCTO
                                      where (
                                             data.Nombre.ToString().ToUpper().Contains(valor.ToUpper()) ||
                                             data.Descripcion.ToString().ToUpper().Contains(valor.ToUpper()) ||
                                             data.Categoria.ToString().ToUpper().Contains(valor.ToUpper())
                                            )
                                      select new ProductoModel
                                      {
                                          ProductoId = data.ProductoId,
                                          Nombre = data.Nombre,
                                          Descripcion = data.Descripcion,
                                          Categoria = data.Categoria,
                                          Imagen = data.Imagen
                                      }).ToList();
                }
                return listaProductos;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.GetType().FullName);
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        [Route("api/CrearProducto")]
        [HttpPost]
        public void CrearProducto(ProductoModel request)
        {
            try
            {
                using (BDEntities bdModel = new BDEntities())
                {
                    PRODUCTO producto = new PRODUCTO();
                    producto.Nombre = request.Nombre;
                    producto.Descripcion = request.Descripcion;
                    producto.Categoria = request.Categoria;
                    producto.Imagen = request.Imagen;
                    bdModel.PRODUCTO.Add(producto);
                    bdModel.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.GetType().FullName);
                Console.WriteLine(ex.Message);
            }
        }

        [Route("api/EditarProducto/{id}")]
        [HttpPut]
        public void EditarProducto(int id, ProductoModel request)
        {
            try
            {
                using (BDEntities bdModel = new BDEntities())
                {
                    PRODUCTO producto = bdModel.PRODUCTO.Find(id);
                    producto.Nombre = request.Nombre;
                    producto.Descripcion = request.Descripcion;
                    producto.Categoria = request.Categoria;
                    producto.Imagen = request.Imagen;
                    bdModel.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.GetType().FullName);
                Console.WriteLine(ex.Message);
            }
        }

        [Route("api/EliminarProducto/{id}")]
        [HttpDelete]
        public void EliminarProducto(int id)
        {
            try
            {
                using (BDEntities bdModel = new BDEntities())
                {
                    PRODUCTO producto = bdModel.PRODUCTO.Find(id);
                    bdModel.PRODUCTO.Remove(producto);
                    bdModel.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.GetType().FullName);
                Console.WriteLine(ex.Message);
            }
        }
    }
}